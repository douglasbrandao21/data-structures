#include <stdio.h>
#include "queue.h"

int main() {
    Queue *queue = createQueue();

    enqueue(queue, 1);
    enqueue(queue, 2);
    enqueue(queue, 3);
    enqueue(queue, 4);
    enqueue(queue, 5);

    showFirstN(queue, 5);

    dequeue(queue);
    dequeue(queue);

    enqueue(queue, 10);
    enqueue(queue, 42);

    showFirstN(queue, 10);

    clear(queue);

    showFirstN(queue, 10);

    return 0;
}

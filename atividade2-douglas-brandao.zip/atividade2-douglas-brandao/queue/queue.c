//
// Created by douglas on 01/04/24.
//
#include "queue.h"

#include <stdio.h>
#include <stdlib.h>

Node* createNode(int data) {
    Node* node = (Node*) malloc(sizeof (Node));

    node->data = data;
    node->next = NULL;
    node->previous = NULL;

    return node;
}

Queue* createQueue() {
    Queue *queue = (Queue*) malloc(sizeof(Queue));

    queue->size = 0;
    queue->head = NULL;
    queue->tail = NULL;

    return queue;
}

void clear(Queue *queue) {
    Node *node, *next;

    for(node = queue->head; node != NULL; node = next) {
        next = node->next;

        free(node);
    }

    queue->size = 0;
    queue->head = queue->tail = NULL;
}

bool isEmpty(Queue *queue) {
    return queue->size == 0;
}

void enqueue(Queue *queue, int data) {
    Node* node = createNode(data);

    if(isEmpty(queue)) queue->head = queue->tail = node;

    else {
        queue->tail->next = node;
        queue->tail = queue->tail->next;
    }

    queue->size += 1;
}

void dequeue(Queue *queue) {
    if(!isEmpty(queue)) {
        Node *node = queue->head;

        if(queue->size == 1)
            queue->head = queue->tail = NULL;
        else
            queue->head = queue->head->next;

        free(node);

        queue->size -= 1;
    }
}

void showFirstN(Queue *queue, int N) {
    if(isEmpty(queue)) printf("Empty list");
    else {
        Node *node = queue->head;

        if(N > queue->size) N = queue->size;

        printf("\n[");

        for(int index = 0; index < N; index++, node = node->next)
            printf(" %d ", node->data);

        printf("]\n");
    }
}

//
// Created by douglas on 01/04/24.
//

#ifndef C_IMPLEMENTATION_QUEUE_H
#define C_IMPLEMENTATION_QUEUE_H

#include <stdbool.h>

typedef struct Node {
    int data;
    struct Node *next;
    struct Node *previous;
} Node;

typedef struct Queue {
    int size;
    Node *head;
    Node *tail;
} Queue;

Node* createNode(int data);

Queue* createQueue();

void clear(Queue *queue);

bool isEmpty(Queue *queue);

void enqueue(Queue *queue, int data);
void dequeue(Queue *queue);

void showFirstN(Queue *queue, int N);

#endif //C_IMPLEMENTATION_QUEUE_H

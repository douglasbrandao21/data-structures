#include <stdio.h>

#include "stack.h"

int main() {
    Stack *stack = createStack();

    push(stack, 1);
    push(stack, 2);
    push(stack, 3);
    push(stack, 4);
    push(stack, 5);

    showNFirst(stack, 10);

    clear(stack);

    push(stack, 6);
    push(stack, 7);
    push(stack, 8);
    push(stack, 9);

    pop(stack);
    pop(stack);

    showNFirst(stack, 5);

    showTop(stack);

    return 0;
}

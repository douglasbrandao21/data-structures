//
// Created by douglas on 01/04/24.
//

#ifndef C_IMPLEMENTATION_STACK_H
#define C_IMPLEMENTATION_STACK_H

#include <stdlib.h>
#include <stdlib.h>
#include <stdbool.h>

typedef struct Node {
    int data;
    struct Node *next;
    struct Node *previous;
} Node;

typedef struct {
    int size;
    Node *head;
    Node *tail;
} Stack;

Stack* createStack();
Node* createNode(int data);

bool isEmpty(Stack* stack);

void clear(Stack* stack);

void pop(Stack *stack);
void push(Stack* stack, int data);

void showTop(Stack* stack);

void showNFirst(Stack *stack, int N);

#endif //C_IMPLEMENTATION_STACK_H

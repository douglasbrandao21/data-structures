//
// Created by douglas on 01/04/24.
//
#include <stdio.h>

#include "stack.h"

Node* createNode(int data) {
    Node *node = (Node*) malloc(sizeof (Node));

    node->data = data;
    node->next = NULL;
    node->previous = NULL;

    return node;
}

Stack* createStack() {
    Stack* stack = (Stack*) malloc(sizeof (Stack));

    stack->size = 0;
    stack->head = NULL;
    stack->tail = NULL;

    return stack;
}

bool isEmpty(Stack *stack) {
    return stack->size == 0;
}

void clear(Stack *stack) {
    Node *next;
    Node *node = stack->head;

    for(node = stack->head; node != NULL; node = next) {
        next = node->next;

        free(node);
    }

    stack->size = 0;
    stack->head = NULL;
    stack->tail = NULL;
}

void pop(Stack *stack) {
    if(stack->size == 1) {
        free(stack->head);

        stack->head = stack->tail = NULL;
    }
    else {
        stack->tail = stack->tail->previous;

        free(stack->tail->next);

        stack->tail->next = NULL;
    }

    stack->size -= 1;
}

void push(Stack *stack, int data) {
    Node *node = createNode(data);

    if(isEmpty(stack) == true) stack->head = stack->tail = node;

    else {
        node->previous = stack->tail;
        stack->tail = node;
        stack->tail->previous->next = stack->tail;
    }

    stack->size += 1;
}

void showTop(Stack *stack) {
    printf("Top of the Stack: %d", stack->tail->data);
}

void showNFirst(Stack *stack, int N) {
    Node *last = stack->tail;

    if(N > stack->size) N = stack->size;

    if(stack->size > 0) {
        printf("---\n");

        for(int index = 0; index < N; index++, last = last->previous)
            printf(" %d \n", last->data);

        printf("---\n\n");
    }
}


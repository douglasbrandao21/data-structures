//
// Created by douglas on 09/04/24.
//

#ifndef C_IMPLEMENTATION_HASH_TABLE_H
#define C_IMPLEMENTATION_HASH_TABLE_H

#define SET_SIZE 10

typedef struct {
    int size;
    int setSize;

    char* set[SET_SIZE];
} HashTable;


/**
 * Creates an HashTable
 *
 * @return A pointer to an HashTable Struct
 */
HashTable* createHashTable();


/**
 * Insert some data inside of a given HashTable
 *
 * @param hashTable HashTable
 * @param key Key of the data to be inserted
 * @param data Data to be inserted
 */
void insert(HashTable *hashTable, int key, char* data);

#endif //C_IMPLEMENTATION_HASH_TABLE_H

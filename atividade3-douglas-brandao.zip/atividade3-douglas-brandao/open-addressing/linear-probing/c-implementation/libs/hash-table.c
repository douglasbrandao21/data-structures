//
// Created by douglas on 09/04/24.
//
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include "hash-table.h"

int hash(int key, int setSize) {
    double k = (double)key;
    double A = 0.357840;

    double M = (double) setSize * fmod((A*k), 1.0);

    return floor(M);
}


HashTable* createHashTable() {
    HashTable *hashTable = (HashTable*) malloc(sizeof (HashTable));

    hashTable->size = 0;
    hashTable->setSize = SET_SIZE;

    return hashTable;
}

void insert(HashTable *hashTable, int key, char* data) {
    int index = hash(key, hashTable->setSize);

    printf("Key for data %s: %d\n", data, index);

    while(hashTable->set[index] != NULL)
        index +=1;

    hashTable->set[index] = data;
}
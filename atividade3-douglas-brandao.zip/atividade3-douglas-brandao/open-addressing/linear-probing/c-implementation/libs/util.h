//
// Created by douglas on 09/04/24.
//

#ifndef C_IMPLEMENTATION_UTIL_H
#define C_IMPLEMENTATION_UTIL_H

typedef struct {
    int key;
    char* name;
} Pirate[10];

Pirate pirates = {
        372, "Portgas D. Ace",
        498, "Sabo",
        180, "Roronoa Zoro",
        178, "Luffy",
        225, "Trafalgar D. Water Law",
        169, "Jimbe",
        129, "Donquixote Doflamingo",
        460, "Capone Bege",
        148, "Dracule Mihawk",
        373, "Alvida"
};

#endif //C_IMPLEMENTATION_UTIL_H

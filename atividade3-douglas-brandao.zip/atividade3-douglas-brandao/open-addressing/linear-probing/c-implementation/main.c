#include "libs/util.h"
#include "libs/hash-table.h"

int main() {
    HashTable *hashTable = createHashTable();

    insert(hashTable, pirates[0].key, pirates[0].name);
    insert(hashTable, pirates[1].key, pirates[1].name);
    insert(hashTable, pirates[2].key, pirates[2].name);
    insert(hashTable, pirates[3].key, pirates[3].name);
    insert(hashTable, pirates[4].key, pirates[4].name);
    insert(hashTable, pirates[5].key, pirates[5].name);

    return 0;
}

//
// Created by douglas on 08/04/24.
//

#ifndef C_IMPLEMENTATION_HASH_TABLE_H
#define C_IMPLEMENTATION_HASH_TABLE_H

#define SET_SIZE 5

typedef struct Node
{
    int key;
    char *data;

    struct Node *next;
} Node;

typedef struct
{
    int size;

    /**
     *
     * We could declare our array of Nodes like that, a pointer to pointers.
     * But in this case, I opted to declare in a static way, just because I can
     * see on the CLion Debugger tool the exact form of my HashTable
     * Node **set;
     */

    Node *set[SET_SIZE];
} HashTable;

/**
 * Creates an HashTable
 *
 * @return A pointer to an HashTable Struct
 */
HashTable *createHashTable();

/**
 * Insert some data inside of a given HashTable
 *
 * @param hashTable HashTable
 * @param key Key of the data to be inserted
 * @param data Data to be inserted
 */
void insert(HashTable *hashTable, int key, char *data);

/**
 * Delete a key from a given HashTable
 *
 * @param hashTable HashTable having data removed
 * @param key Key of the to be removed data
 */
void delete(HashTable *hashTable, int key);

/**
 * Returns data from a given HashTable
 *
 * @param hashTable HashTable to query data
 * @param key Key of the data to be queried
 *
 * @return Queried data
 */
char *search(HashTable *hashTable, int key);

#endif // C_IMPLEMENTATION_HASH_TABLE_H

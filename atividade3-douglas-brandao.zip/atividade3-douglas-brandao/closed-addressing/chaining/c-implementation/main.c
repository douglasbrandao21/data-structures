#include <stdio.h>
#include "hash-table.h"

typedef struct {
    int key;
    char* name;
} Pirate[10];

Pirate pirates = {
        372, "Portgas D. Ace",
        498, "Sabo",
        180, "Roronoa Zoro",
        178, "Luffy",
        225, "Trafalgar D. Water Law",
        169, "Jimbe",
        129, "Donquixote Doflamingo",
        460, "Capone Bege",
        148, "Dracule Mihawk",
        373, "Alvida"
};


int main() {
    HashTable *hashTable = createHashTable();

    for(int index = 0; index < 10; index++)
        insert(hashTable, pirates[index].key, pirates[index].name);

    // Must be "Portgas D. Ace"
    printf("%s\n", search(hashTable, pirates[0].key));

    // Must be "Roronoa Zoro"
    printf("%s\n", search(hashTable, pirates[2].key));

    // Must be "Trafalgar D. Water Law"
    printf("%s\n", search(hashTable, pirates[4].key));

    // Must be "Donquixote Doflamingo"
    printf("%s\n", search(hashTable, pirates[6].key));

    // Must be "Dracule Mihawk"
    printf("%s\n", search(hashTable, pirates[8].key));

    printf("\nBefore Deleting Key %d: %s\n", pirates[0].key, search(hashTable, pirates[0].key));

    delete(hashTable, pirates[0].key);

    printf("After Deleted Key %d: %s\n", pirates[0].key, search(hashTable, pirates[0].key));
}

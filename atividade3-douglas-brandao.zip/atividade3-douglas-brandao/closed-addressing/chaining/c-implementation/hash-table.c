//
// Created by douglas on 08/04/24.
//
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "hash-table.h"


int hash(int key) {
    double k = (double)key;
    double A = 0.357840;

    double M = (double) SET_SIZE * fmod((A*k), 1.0);

    return floor(M);
}

HashTable* createHashTable() {
    HashTable *hashTable = (HashTable*) malloc(sizeof (HashTable));

    hashTable->size = 0;

    /**
     * Again, we could initialize our array of pointers dynamically, but just for debug
     * purposes we're using a static allocation
     *
     * hashTable->set = (Node**) malloc(sizeof(Node*) * SET_SIZE)
     */

    return hashTable;
}


void insert(HashTable *hashTable, int key, char *data) {
    int index = hash(key);

    Node *node = (Node*) malloc(sizeof (Node));

    node->key = key;
    node->data = data;
    node->next = NULL;

    if(hashTable->set[index] == NULL) {
        hashTable->set[index] = node;
    }
    else {
        node->next = hashTable->set[index];

        hashTable->set[index] = node;
    }
}


void delete(HashTable *hashTable, int key) {
    int index = hash(key);

    Node *previous;
    Node *current = hashTable->set[index];

    while(current != NULL) {
        if(key == current->key) {
            if(current == hashTable->set[index]) // Deleting from beginning
                hashTable->set[index] = current->next;
            else // Deleting from middle or end
                previous->next = current->next;

            free(current);

            break;
        }

        previous = current;
        current = current->next;
    }
}


char* search(HashTable *hashTable, int key) {
    int index = hash(key);

    Node *head;

    for(head = hashTable->set[index]; head != NULL; head = head->next)
        if(head->key == key) return head->data;

    return "No data was found";
}